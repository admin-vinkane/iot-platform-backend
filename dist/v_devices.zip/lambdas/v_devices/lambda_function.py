
import json, os, boto3
from shared import response_utils
TABLE = os.environ.get("TABLE_NAME", "v_devices")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE)
def lambda_handler(event, context):
    method = event.get("httpMethod") or event.get("requestContext",{}).get("http",{}).get("method")
    if method == "POST":
        body = json.loads(event.get("body","{}"))
        if "PK" not in body or "SK" not in body:
            return response_utils.error_response("Missing PK or SK in body")
        body.setdefault("created_date", context.aws_request_id if context else "")
        table.put_item(Item=body)
        return response_utils.success_response({"message":"created","item":body})
    if method == "GET":
        params = event.get("queryStringParameters") or event.get("pathParameters") or {}
        pk = params.get("PK") or params.get("pk")
        sk = params.get("SK") or params.get("sk")
        if not pk or not sk:
            return response_utils.error_response("Missing PK or SK for GET")
        r = table.get_item(Key={"PK": pk, "SK": sk})
        return response_utils.success_response(r.get("Item"))
    if method == "PUT":
        body = json.loads(event.get("body","{}"))
        if "PK" not in body or "SK" not in body:
            return response_utils.error_response("Missing PK or SK in body")
        body.setdefault("updated_date", context.aws_request_id if context else "")
        table.put_item(Item=body)
        return response_utils.success_response({"message":"updated","item":body})
    if method == "DELETE":
        params = event.get("queryStringParameters") or {}
        pk = params.get("PK") or params.get("pk")
        sk = params.get("SK") or params.get("sk")
        if not pk or not sk:
            return response_utils.error_response("Missing PK or SK for DELETE")
        table.delete_item(Key={"PK": pk, "SK": sk})
        return response_utils.success_response({"message":"deleted"})
    return response_utils.error_response("Unsupported method", 405)
